#!/usr/bin/env bash
# "Yontem 2"yi gercekten calistirir: zip'i API ile yukler, Actions isini
# tetikler, sonucu dogrular, GitHub Pages'i acar ve canli adresi kontrol eder.
#
#   bash yayinla.sh          # gercek yayin (gh oturumu veya GH_TOKEN sart)
#   KURU=1 bash yayinla.sh   # kimlik gerektirmez: plan + yerel kontroller
#
# Sirlar: token yalnizca gh'in kendi deposundan / GH_TOKEN ortam degiskeninden
# okunur; bu betik tokeni yazmaz, ekrana basmaz, dosyaya koymaz.
set -uo pipefail

SRC=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
REPO=${REPO:-tnygnz/suomi-kartat}
ZIP=sanat-web-yukle.zip
WFPATH=.github/workflows/zip-ac.yml
SITE=https://tnygnz.github.io/suomi-kartat/sanat/index.html
API=repos/$REPO
KURU=${KURU:-0}
WORK=$(mktemp -d "${TMPDIR:-/tmp}/yayinla.XXXXXX")
trap 'rm -rf "$WORK"' EXIT

pass=0; fail=0
ok()   { pass=$((pass + 1)); printf '  ok    %s\n' "$1"; }
bad()  { fail=$((fail + 1)); printf '  FAIL  %s\n' "$1"; }
step() { printf '\n%s\n' "$1"; }
die()  { printf '\nDURDU: %s\n' "$1" >&2; exit "${2:-1}"; }

# ---------------------------------------------------------------- 0) yerel
step "0) Yerel hazirlik (kimlik gerekmez)"
git -C "$SRC" rev-parse --git-dir >/dev/null 2>&1 || die "bu betik bir git deposunda calismali" 2
[ -f "$SRC/PUSH.md" ] || die "PUSH.md yok" 2
if [ ! -f "$SRC/$ZIP" ]; then
  git -C "$SRC" archive --format=zip -o "$SRC/$ZIP" HEAD || die "zip uretilemedi" 2
  ok "zip HEAD'den uretildi"
else
  ok "zip hazir: $ZIP ($(wc -c < "$SRC/$ZIP") bayt)"
fi

# PUSH.md'deki is akisini cikar (yayindan once yerelde dogrula)
awk '
  /^[[:space:]]*```yaml[[:space:]]*$/ { iny = 1; next }
  iny && /^[[:space:]]*```[[:space:]]*$/ { iny = 0; next }
  iny { l = $0; sub(/^[ ]{1,3}/, "", l); print l }
' "$SRC/PUSH.md" > "$WORK/zip-ac.yml"
[ -s "$WORK/zip-ac.yml" ] || die "PUSH.md icinde yaml blogu yok" 2
if command -v python3 >/dev/null 2>&1 && python3 -c 'import yaml' 2>/dev/null; then
  steps=$(python3 - "$WORK/zip-ac.yml" <<'PY'
import sys, yaml
wf = yaml.safe_load(open(sys.argv[1], encoding="utf-8"))
print(sum(len([s for s in (j or {}).get("steps", []) if "run" in s]) for j in wf["jobs"].values()))
PY
) || die "PUSH.md'deki YAML gecersiz" 2
  ok "is akisi gecerli, $steps run: adimi"
else
  grep -q 'unzip .*'"$ZIP" "$WORK/zip-ac.yml" && ok "is akisi awk ile okundu" \
    || die "is akisinda $ZIP gecmiyor" 2
fi

# ---------------------------------------------------------------- kuru mod
if [ "$KURU" = "1" ]; then
  step "KURU calistirma: aga yazilmayacak"
  if b64=$(python3 - "sanat/app.js" "$SRC/$ZIP" "$WORK/govde.json" <<'PY' 2>/dev/null
import base64, json, sys
path, f, out = sys.argv[1:4]
d = {"message": "kuru", "content": base64.b64encode(open(f, "rb").read()).decode()}
open(out, "w").write(json.dumps(d))
print(len(d["content"]))
PY
  ); then
    ok "API govdesi base64 ile kuruluyor: $b64 karakter, $(wc -c < "$WORK/govde.json") bayt JSON"; else
    command -v base64 >/dev/null && ok "python3 yok; base64 yedegi kullanilacak" \
      || bad "ne python3 ne base64 var"
  fi
  printf '  plan  PUT %s/contents/%s\n' "$API" "$ZIP"
  printf '  plan  PUT %s/contents/%s\n' "$API" "$WFPATH"
  printf '  plan  gh workflow run zip-ac.yml --repo %s\n' "$REPO"
  printf '  plan  POST %s/pages (source: main, /) + derleme bekleme\n' "$API"
  printf '  plan  HTTP 200 kontrolu: %s\n' "$SITE"
  step "SONUC (kuru)"
  printf '  %d gecti, %d basarisiz\n' "$pass" "$fail"
  [ "$fail" -eq 0 ] || exit 1
  exit 0
fi

# ---------------------------------------------------------------- 1) kimlik
step "1) Kimlik dogrulama"
command -v gh >/dev/null 2>&1 || die "gh kurulu degil: https://cli.github.com" 3
if ! gh auth status >/dev/null 2>&1; then
  die "GitHub oturumu yok. Yapilacaklar:
  1) GitHub -> Settings -> Developer settings -> Tokens (classic) -> repo kapsamli token
  2) Bu projede Settings -> Secrets -> GH_TOKEN olarak ekle (sohbete yapistirma)
  3) Ayni komutu yeniden calistir:  bash yayinla.sh
  Alternatif: kendi terminalinde 'gh auth login' (etkilesimli, bu ortamda mumkun degil)." 3
fi
gh auth status 2>&1 | sed -n '1,2p' | sed 's/^/  /'
ok "gh oturumu etkin"

default_branch=$(gh api "$API" --jq .default_branch) || die "depoya erisilemiyor: $REPO" 4
[ "$default_branch" = "main" ] && ok "varsayilan dal: main" || bad "varsayilan dal main degil: $default_branch"

# ---------------------------------------------------------------- 2) yukle
step "2) Zip ve is akisi yukleniyor (web arayuzunun API karsiligi)"
put_dosya() { # $1=depo yolu $2=commit mesaji $3=yerel dosya $4=etik
  local path=$1 msg=$2 f=$3 label=$4 sha
  sha=$(gh api "$API/contents/$path" --jq .sha 2>/dev/null || true)
  python3 - "$path" "$msg" "$f" "${sha:-}" > "$WORK/govde.json" <<'PY' || return 1
import base64, json, sys
path, msg, f, sha = sys.argv[1:5]
d = {"message": msg, "content": base64.b64encode(open(f, "rb").read()).decode()}
if sha:
    d["sha"] = sha
print(json.dumps(d))
PY
  if gh api --method PUT "$API/contents/$path" --input "$WORK/govde.json" --jq .commit.sha >/dev/null; then
    ok "$label yuklendi${sha:+ (uzerine yazildi)}"
  else
    bad "$label yuklenemedi"; return 1
  fi
}
put_dosya "$ZIP" "Add files via upload" "$SRC/$ZIP" "zip" || die "zip yuklenemedi" 5
put_dosya "$WFPATH" "Create zip-ac.yml" "$WORK/zip-ac.yml" "is akisi" || die "is akisi yuklenemedi" 5

# ---------------------------------------------------------------- 3) actions
step "3) Is tetikleniyor"
gh workflow run zip-ac.yml --repo "$REPO" --ref main >/dev/null 2>&1 \
  && ok "zip-ac kuyruga alindi" || bad "is tetiklenemedi"
run_id=""
for _ in $(seq 1 30); do
  sleep 4
  run_id=$(gh run list --repo "$REPO" --workflow zip-ac.yml --limit 1 \
    --json databaseId,status --jq '.[0].databaseId' 2>/dev/null || true)
  [ -n "$run_id" ] && break
done
[ -n "$run_id" ] || die "is kaydi bulunamadi (Actions kapali olabilir)" 6
printf '  kosu kimligi: %s\n' "$run_id"
durum=""
for _ in $(seq 1 45); do
  durum=$(gh run view "$run_id" --repo "$REPO" --json status,conclusion \
    --jq '[.status, (.conclusion // "-")] | @tsv' 2>/dev/null || echo "unknown	-")
  set -- $durum
  [ "${1:-}" = "completed" ] && break
  sleep 8
done
set -- $durum
if [ "${1:-}" = "completed" ] && [ "${2:-}" = "success" ]; then
  ok "is basariyla bitti"
else
  bad "is bitmedi/patladi: ${durum:-bilinmiyor}"
  gh run view "$run_id" --repo "$REPO" --log-failed 2>/dev/null | tail -15 | sed 's/^/  /'
fi

# ---------------------------------------------------------------- 4) icerik
step "4) Depo icerigi"
[ "$(gh api "$API/contents/sanat?ref=main" --jq 'length' 2>/dev/null || echo 0)" = "13" ] \
  && ok "sanat/ altinda 13 dosya" || bad "sanat/ dosya sayisi beklenenden farkli"
if gh api "$API/contents/$ZIP?ref=main" >/dev/null 2>&1; then
  bad "zip hala depoda (is silmemis)"
else
  ok "zip depodan silinmis"
fi
[ "$(gh api "$API/contents/README.md?ref=main" --jq .name 2>/dev/null || echo -)" = "README.md" ] \
  && ok "README.md korunmus" || bad "README.md yok"
uzak_app=$(gh api "$API/contents/sanat/app.js?ref=main" --jq .sha 2>/dev/null || echo -)
yerel_app=$(git -C "$SRC" rev-parse HEAD:sanat/app.js)
[ "$uzak_app" = "$yerel_app" ] && ok "app.js blob sha bu depoyla ayni" \
  || bad "app.js uzakta farkli (uzak: ${uzak_app:0:8}, yerel: ${yerel_app:0:8})"

# ---------------------------------------------------------------- 5) pages
step "5) GitHub Pages"
if gh api "$API/pages" >/dev/null 2>&1; then
  ok "Pages zaten acik: $(gh api "$API/pages" --jq .html_url 2>/dev/null)"
else
  if gh api --method POST "$API/pages" -f "source[branch]=main" -f "source[path]=/" \
       --jq .html_url > "$WORK/pages.txt" 2>"$WORK/pages.err"; then
    ok "Pages acildi: $(cat "$WORK/pages.txt")"
  else
    bad "Pages acilamadi: $(head -2 "$WORK/pages.err" | tr '\n' ' ')"
  fi
fi
sayac=0
for _ in $(seq 1 40); do
  b=$(gh api "$API/pages/builds/latest" --jq '[.status, (.error.message // "-")] | @tsv' 2>/dev/null || echo "yok	-")
  set -- $b
  [ "${1:-}" = "built" ] && break
  sayac=$((sayac + 1)); sleep 10
done
set -- $b
[ "${1:-}" = "built" ] && ok "Pages derlemesi tamam (${sayac}0 sn beklendi)" \
  || bad "Pages derlemesi tamamlanmadi: ${b:-bilinmiyor}"

step "6) Canli adres"
kod=$(curl -sS -o "$WORK/sayfa.html" -w '%{http_code}' "$SITE" 2>/dev/null || echo 000)
[ "$kod" = "200" ] && ok "index.html: HTTP $kod" || bad "index.html: HTTP $kod"
grep -q 'Sanat — Fince' "$WORK/sayfa.html" 2>/dev/null \
  && ok "baslik dogru (Sanat — Fince)" || bad "baslik beklenen metni icermiyor"
grep -q 'id="i-study"' "$WORK/sayfa.html" 2>/dev/null \
  && ok "SVG ikon seti sayfada" || bad "SVG ikon seti yok"
css=$(curl -sS -o /dev/null -w '%{http_code} %{content_type}' "${SITE%/index.html}/styles.css" 2>/dev/null || echo "000 -")
set -- $css
[ "${1:-}" = "200" ] && ok "styles.css: HTTP 200, ${2:-?}" || bad "styles.css: $css"
app=$(curl -sS -o /dev/null -w '%{http_code}' "${SITE%/index.html}/app.js" 2>/dev/null || echo 000)
[ "$app" = "200" ] && ok "app.js: HTTP 200" || bad "app.js: HTTP $app"

step "SONUC"
printf '  %d gecti, %d basarisiz\n' "$pass" "$fail"
printf '  site: %s\n' "$SITE"
[ "$fail" -eq 0 ] || exit 1
